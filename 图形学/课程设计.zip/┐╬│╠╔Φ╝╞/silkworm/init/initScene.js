var scene;


function initScene(){
    scene = new THREE.Scene();

}